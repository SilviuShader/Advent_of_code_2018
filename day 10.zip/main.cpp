#include <fstream>
#include <iostream>

#include <string.h>
#include <conio.h>

#include <vector>

#define MAX_STARS 1000

struct Star
{
    int x;
    int y;

    int velX;
    int velY;
};

using namespace std;

ifstream fin;
ofstream fout;

vector<Star> stars;

bool starsMatrix[MAX_STARS][MAX_STARS] = { 0 };

void Read()
{
    char dumb;
    int posX;
    int posY;
    int velX;
    int velY;

    while(fin >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >>
          posX >> dumb >> posY >>
          dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >> dumb >>
          velX >> dumb >> velY >> dumb)
          {
              Star star;
              star.x = posX;
              star.y = posY;
              star.velX = velX;
              star.velY = velY;

              stars.push_back(star);
          }
}

void ApplyVelocity()
{
    for(int i = 0; i < stars.size(); i++)
    {
        stars[i].x += stars[i].velX;
        stars[i].y += stars[i].velY;
    }
}

void NormalizeStars()
{
    int minX = stars[0].x;
    int minY = stars[0].y;

    for(int i = 0; i < stars.size(); i++)
    {
        if(stars[i].x < minX)
            minX = stars[i].x;

        if(stars[i].y < minY)
            minY = stars[i].y;
    }

    for(int i = 0; i < stars.size(); i++)
    {
        stars[i].x -= minX;
        stars[i].y -= minY;
    }
}

void CreateAndShowMatrix()
{
    for(int i = 0; i < stars.size(); i++)
    {
        if(stars[i].y < MAX_STARS && stars[i].y >= 0 &&
           stars[i].x < MAX_STARS && stars[i].x >= 0)
        {
            starsMatrix[stars[i].y][stars[i].x] = true;
        }
    }

    for(int i = 0; i < MAX_STARS; i++)
    {
        for(int j = 0; j < MAX_STARS; j++)
        {
            fout << (starsMatrix[i][j] ? "*" : " ");
        }
        fout << endl;
    }

    fout << endl;
}

void Solve1()
{
    for(int i = 0; i < 10889; i++)
    {
        ApplyVelocity();
        NormalizeStars();

        memset(starsMatrix, false, sizeof(bool) * MAX_STARS * MAX_STARS);


       // cout << stars[30].x << " " << stars[30].y << " " << i << endl;

        if(i >= 10887)
        {
            fout << i << endl;
            CreateAndShowMatrix();
        }
    }
}

int main()
{
    fin.open("input.in");
    fout.open("output.out");

    Read();
    Solve1();

    fin.close();
    fout.close();

    return 0;
}
